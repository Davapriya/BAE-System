var singleApp=angular.module('countrySelection',[]);
singleApp.controller('searchController', function($scope,$http) {   
 /** API CAll **/   
    $http.get('json/location.json').success(function(response) {  
        $scope.results = response;
		var countryCount = [];        

        angular.forEach($scope.results, function(value, key) {
            if (countryCount.indexOf(value.country) === -1)
            countryCount.push(value.country);
        });			
		$scope.chooseCountry = countryCount;
        
 /***City Selection***/       
        $scope.countryChange=function() {
            var cityCount = [];
            var countrySelVal = $scope.countrySelect;   
                angular.forEach(response, function(value, key){  
                    if(value.country == $scope.countrySelect){
                        if(cityCount.indexOf(value.city) === -1) {
                        cityCount.push(value.city);
                        }	
                    }
                });
            $scope.chooseCity = cityCount;
			console.log(cityCount)
        }
        
    });
});

/***Map***/
singleApp.directive('myMap', function() {
    // directive link function
    var link = function(scope, element, attrs) {
        var map, infoWindow;
        var markers = [];
        // init the map
        function initMap(lat, lan) {
            var mapOptions = {
                center: new google.maps.LatLng(lat, lan),
                zoom: 12,
                mapTypeId: google.maps.MapTypeId.ROADMAP,
                scrollwheel: true
            }
            if (map === void 0) {
                map = new google.maps.Map(element[0], mapOptions);
            }
        }    
        
        // place a marker
        function setMarker(map, position, title, content) {
            var marker;
            var markerOptions = {
                position: position,
                map: map,
                title: title,
                icon: 'https://maps.google.com/mapfiles/ms/icons/red-dot.png'
            };

            marker = new google.maps.Marker(markerOptions);
            markers.push(marker); // add marker to array
            
            google.maps.event.addListener(marker, 'mouseover', function () {
                // close window if not undefined
                if (infoWindow !== void 0) {
                    infoWindow.close();
                }
                // create new window
                var infoWindowOptions = {
                    content: content
                };
                infoWindow = new google.maps.InfoWindow(infoWindowOptions);
                infoWindow.open(map, marker);
            });
        }
        
        function removeMarkers(){
            for(i=0; i<markers.length; i++){
                markers[i].setMap(null);
            }
        }
        
        // show the map and place some markers
        initMap(3.100753, 101.667495);
            
        scope.$watch('countrySelect', function() {
            var currentLocations = [], i=0, lastLattitude = '', lastLongtitude ='';            
            if(scope.countrySelect != undefined) {
                removeMarkers();
                angular.forEach(scope.results, function(value, key) {
                    if(value.country == scope.countrySelect) {  
                        if(i == 0) {
                            map.setCenter(new google.maps.LatLng(value.lat, value.lng), 12);                
                        }
                        setMarker(map, new google.maps.LatLng(value.lat, value.lng), value.country, '<b>Address:</b>'+value.address+'<br/>City:'+value.city+'<br/>Postal Code:'+value.postalCode);                      
                        i++;
                    }
                });
            }
            
        });
        
        scope.$watch('citySelect', function(){
            var currentLocations = [], i=0;
            if(scope.citySelect != undefined){
                removeMarkers();
                angular.forEach(scope.results, function(value,key){
                    if(value.city == scope.citySelect) {                        
                        if(i == 0) {
                            map.setCenter(new google.maps.LatLng(value.lat, value.lng), 12);                
                        }
                        setMarker(map, new google.maps.LatLng(value.lat, value.lng), value.country, '<b>Address:</b>'+value.address+'<br/>City:'+value.city+'<br/>Postal Code:'+value.postalCode);                      
                        i++;
                    }
                });
            }
        });
       
    };
    
    return {
        restrict: 'A',
        template: '<div id="gmaps"></div>',
        replace: true,
        link:link
    };
   
});